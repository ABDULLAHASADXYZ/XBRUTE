#!/bin/bash
python3 -m venv myenv
source myenv/bin/activate

python3 cmd/main.py
